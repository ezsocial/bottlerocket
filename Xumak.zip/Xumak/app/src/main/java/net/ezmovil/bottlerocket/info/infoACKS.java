package net.ezmovil.bottlerocket.info;

public final class infoACKS {
	public static int _ack;
    public static String _token;
    public static int _gennameid;

    public infoACKS() {
    	;
    }

    public void setAck(String __ack) {
        _token = __ack;
    }
    
    public int getAck()
    {
        return _ack;
    }
    public String getToken()
    {
        return _token;
    }

    public int get_gennameid()
    {
        return _gennameid;
    }
    public int get_genameid()
    {
        return _gennameid;
    }

}
