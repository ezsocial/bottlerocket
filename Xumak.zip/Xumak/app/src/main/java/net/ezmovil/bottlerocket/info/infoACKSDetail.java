package net.ezmovil.bottlerocket.info;

public final class infoACKSDetail {
	public static int _ack;
    public static String _token;
    public infoACKSDetail() {
    	;
    }

    public void setAck(String __ack) {
        _token = __ack;
    }
    
    public int getAck()
    {
        return _ack;
    }
    public String getToken()
    {
        return _token;
    }

}
